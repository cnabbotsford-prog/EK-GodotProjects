extends Node3D

# Creates the speed variable to be set by the player
@export var speed: float
# Creates an enum for the player to select what sort of game they want the controls to be for.
enum MovementType
{
	AllDirections,
	HorizontalOnly,
	VerticalOnly
}

# --------------------
# TODO STEP 52
# Add a reference to the AnimationTree node.
# --------------------
@onready var AnimTree: AnimationTree = $"../../AnimationTree"
# The variable for the player to select the movement type
@export var movementType: MovementType = MovementType.AllDirections

# The variable for if the game is a platformer or not
@export var platformSettings: bool = false

# Private master peed variable to control the speed of the parent object
var masterSpeed: float;

# A function that runs when it is initalized, but hasnt been added to the game yet
func _init():
	masterSpeed = speed

# A function that happens at the end of the frame when all of the physics are processed
func _physics_process(delta):
	# Sets left and right and up and down based on preset controls being up, down, left, and right buttons
	var horizontal: float = Input.get_axis("ui_left", "ui_right")
	if Input.is_key_pressed(KEY_A):
		horizontal = -1
	if Input.is_key_pressed(KEY_D):
		horizontal = 1
	var vertical: float = Input.get_axis("ui_down","ui_up")
	if Input.is_key_pressed(KEY_S):
		vertical = -1
	if Input.is_key_pressed(KEY_W):
		vertical = 1
	
	# Checks if the platformSettings bool is checked
	if platformSettings:
		# If it is, gets the RigidBody2D from the parent
		var rigidBody: RigidBody2D = get_parent().get_node("RigidBody2D")
		# Checks it's vertical movement
		var verticalMovement: float = rigidBody.linear_velocity.y
		# If it's not zero, it sets it to the master speed divided by 3
		if verticalMovement != 0:
			speed = masterSpeed / 3
		else:
			# If it is zero, it sets the speed to the master speed
			speed = masterSpeed
	
	# It then checks if the player set the movement speed to horizontal or vertical only
	match movementType:
		MovementType.HorizontalOnly:
			# If its horizontal, it makes it so the player cant move up or down
			vertical = 0
		MovementType.VerticalOnly:
			# If its vertical, it makes it so the player cant move left or right
			horizontal = 0
	
	# Creates the final movement variable based on the final variables
	var movement = Vector3(horizontal,vertical,get_parent().position.z)
	
	# --------------------
	# TODO STEP 53
	# Set the direction the rocket will tilt in.
	# --------------------
	AnimTree["parameters/Blend3/blend_amount"] = horizontal
	# Sets the position based on that movement variable times the time passed times the set speed
	get_parent().position += movement * delta * speed
