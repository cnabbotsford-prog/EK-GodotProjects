extends Node3D

enum CollisionGroup {Default, Player}

@export var group: CollisionGroup = CollisionGroup.Default

# A function that creates and connects the signal to the collision body
func _ready():
	await get_tree().process_frame # makes sure everything is fully loaded before connecting
	
	# Gets parent node Bomb
	var rb: RigidBody3D = get_parent()
	# Sets Bomb max contacts directly in code instead of Editor
	rb.contact_monitor = true
	rb.max_contacts_reported = 1
	
	# Attaches signal to parent node Bomb
	rb.body_entered.connect(collide_with_player)

# A function called by a signal referencing it as when the RigidBody collides with something
func collide_with_player(body):
	# Checks if the collided body is set as in the Player group
	if body.is_in_group(str(CollisionGroup.keys()[group])) or group == CollisionGroup.Default:
		# If it is, reloads the scene after deferring it
		call_deferred("reset_level")
	
	
	
	
# A function called by a signal referencing it as when the RigidBody collides with something
#func collide_with_player(body):
#	# Checks if the collided body is set as in the Player group
#	if body.is_in_group("Player"):
#		# If it is, reloads the scene after deferring it
#		call_deferred("reset_level")
#
func reset_level():
	# Reloads the scene
	if is_inside_tree() and get_tree():
		get_tree().reload_current_scene()
