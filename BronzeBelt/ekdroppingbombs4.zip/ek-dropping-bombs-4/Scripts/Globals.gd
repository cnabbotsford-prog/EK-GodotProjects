extends Node

var started: bool
var spawning: bool
signal hit()
