extends Node3D

@export var rocket: PackedScene

# TODO 1 add on ready variable referencing GameStart

@onready var game_start = get_node("UserInterface/GameStart")

# TODO 6 add on ready variable referencing GameEnd

@onready var game_end = get_node("UserInterface/GameEnd")

var player: Node

func _ready() -> void:
	Globals.hit.connect(game_over)
	# TODO 2 set visible to true
	game_start.visible = true
	# TODO 3 set spawning to false
	Globals.spawning = false
	game_end.visible = false



# TODO 4 process function, if anything pressed visible = false
func _process(_delta: float) -> void:
	if Input.is_anything_pressed() and Globals.spawning == false:
		if Globals.started:
			await get_tree().create_timer(2.0).timeout
			restart()
		else:
			game_start.visible = false
			Globals.spawning = true
			spawn_player()

func game_over():
	# TODO 7 stop spawning bombs, show game end UI 
	game_end.visible = true
	Globals.started = true
	Globals.spawning = false
	player.queue_free()


# TODO 8 restart the game

func restart():
	game_end.visible = false
	Globals.started = false
	Globals.spawning = true
	spawn_player()

func spawn_player():
	var rockets = get_tree().get_nodes_in_group("Rocket")
	if rockets.is_empty(): #to prevent spawning mutliple rockets
		player = rocket.instantiate()
		player.position = Vector3(0,-4.3,0)
		add_child(player)
