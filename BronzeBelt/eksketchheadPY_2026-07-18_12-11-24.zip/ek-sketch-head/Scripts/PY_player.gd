extends CharacterBody2D

# --------------------
# TODO STEP 25
# Create the physics variables
# --------------------
@export var x_velocity: float = 100
@export var y_velocity: float = -700
@export var gravity: float = 1200

#Platform Variables
@export var trampoline_boost : = -1400.0
var is_boosted := false
var is_inverted := 1

# --------------------
# TODO STEP 29
# Create the _process method
# --------------------
func _process(_delta: float) -> void:
	velocity.x = 0.0
	
	if Input.is_action_pressed("ui_left"):
		velocity.x = -x_velocity * is_inverted
		$Sprite2D.flip_h = true
	if Input.is_action_pressed("ui_right"):
		velocity.x = x_velocity * is_inverted
		$Sprite2D.flip_h = false

# --------------------
# TODO STEP 51
# Create the _physics_process method
# --------------------
func _physics_process(delta: float) -> void:
	velocity.y += gravity * delta
	
	move_and_slide()
	
	if is_on_floor():
		# Sets the player controls to default
		is_boosted = false
		is_inverted = 1 
		
		var platform_collision: KinematicCollision2D = get_last_slide_collision()
		
		# Inverts the Players controls if the collider's group is InvertedPlatform
		if (platform_collision.get_collider().is_in_group("InvertedPlatform")):
			is_inverted = -1 
		# Sets the player to a boosted state if the collider's group is TrampolinePlatform
		elif (platform_collision.get_collider().is_in_group("TrampolinePlatform")):
			is_boosted = true
		# Destroys the platform on collision is the collider's group is DisappearingPlatform
		elif (platform_collision.get_collider().is_in_group("DisappearingPlatform")):
			platform_collision.get_collider().queue_free()
			
		if (is_boosted):
			velocity.y = trampoline_boost
		else:
			velocity.y = y_velocity
