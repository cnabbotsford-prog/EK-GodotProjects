extends Node

# -------------------- 
# TODO 1
# Create the variables
# -------------------- 
@export var bomb_scene: PackedScene
var spawn_x: float
var spawn_y: float

# -------------------- 
# TODO 2
# Get the viewport size
# --------------------
func _ready() -> void:
	spawn_x = get_viewport().size.x / 100
	spawn_y = get_viewport().size.y / 100

# -------------------- 
# TODO 3
# Instantiate a bomb object and give it a spawn position
# -------------------- 
func _on_timer_timeout() -> void:
	var bomb = bomb_scene.instantiate()
	bomb.position = Vector3(randf_range(-spawn_x, spawn_x), spawn_y + 5, 0)
	add_child(bomb)
# -------------------- 
# TODO 4
# Remove bomb objects when they've left the viewport
# -------------------- 
func _process(_delta: float) -> void:
	var all_bombs = get_tree().get_nodes_in_group("Bomb")
	for bomb in all_bombs:
		if bomb.position.y < -spawn_y:
			bomb.queue_free()
