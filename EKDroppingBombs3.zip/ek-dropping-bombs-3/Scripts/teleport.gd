extends Node3D

# Allows the player to set the camera and parent object's collision.
@export var mainCamera: Camera3D
@export var bombMesh: CollisionShape3D
# Private variables for setting the size of the screen and size of the parent object
var screenBounds: Vector2
var objectWidth: float
var objectHeight: float

# Called when the node enters the scene tree for the first time.
func _ready():
	# Randomizes seeds so that the random variables randomize each time
	randomize()
	# Sets the screen bounds object to the size of the screen, dividing by 100 to get to Godot units.
	screenBounds = Vector2((mainCamera.get_viewport().size.x/100), (mainCamera.get_viewport().size.y/100))
	# Only really works for objects with Radius, will make one for objects like cubes later
	objectWidth = bombMesh.shape.radius
	objectHeight = bombMesh.shape.radius
	# Calls the Respawn function
	Respawn()

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta):
	# Checks if the parent object is below the screen
	if get_parent().position.y < (screenBounds.y * -1 - objectHeight)-10:
		# if it is, respawns it
		Respawn()

# The respawn function that respawns the parent randomly above the screen
func Respawn():
	# Chooses a random X anywhere from the left to the right side of the screen
	var randomX: float = randf_range(screenBounds.x + objectWidth, screenBounds.x*-1 - objectWidth)
	# Chooses a random Y anywhere above the screen
	var randomY: float = randf_range((screenBounds.y + objectHeight) + 10, (screenBounds.y + objectHeight) + 20)
	
	# Sets the parent's position
	get_parent().position = Vector3(randomX, randomY, 0)
	# Gets the 3D Rigidbody of the parent (Will add an option for 2D later) and then sets it's linear velocity to zero to reset the speed
	var rb: RigidBody3D = get_parent()
	rb.linear_velocity = Vector3.ZERO
