class_name Player
extends CharacterBody2D

@export var xBounds := 310.0

@export var gravity_force: Vector2 = Vector2(0.0, 3000.0)
@export var jump_velocity: float = -1000.0
@export var speed: float = 300.0

var height_score := 0.0

@export var camera: Camera2D
@export var game_over_canvas: CanvasLayer

func _process(delta: float) -> void:
	if velocity.y < 0 and global_position.y < -height_score:
		height_score = -global_position.y
		ScoreSystem.set_score(int(height_score / 150))
		
	if position.y  > camera.position.y + 548:
		game_over_canvas.visible = true
		velocity.y = 0
		gravity_force = Vector2.ZERO

#runs every physics frame
func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity += gravity_force * delta
	if Input.is_action_just_pressed("ui_accept") and is_on_floor():
		velocity.y = jump_velocity
		
	var direction = Input.get_axis("ui_left", "ui_right")
	if direction:
		velocity.x = direction * speed
	else:
		velocity.x = move_toward(velocity.x, 0, speed)
		
	if position.x < -xBounds:
		position.x = xBounds - 10
	if position.x > xBounds:
				position.x = -xBounds + 10
		
	#moves the CharacterBody based on the velocity
	move_and_slide()
