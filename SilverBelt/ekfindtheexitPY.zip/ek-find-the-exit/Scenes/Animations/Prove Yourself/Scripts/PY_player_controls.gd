extends RigidBody3D

const MOVE_SPEED: float = 10.0
const TURN_RATE: float = 0.1

@onready var anim_player: AnimationPlayer = $Run

func _physics_process(delta: float) -> void:
	var input_dir = Vector3()
	# --------------------
	# TODO PROVE YOURSELF
	# Write 3 lines of code to set input_dir's x,
	# set input_dir's z, then set the linear_velocity
	# --------------------
	input_dir.x = Input.get_axis("move_left", "move_right")
	input_dir.z = -1
	linear_velocity = input_dir.normalized() * MOVE_SPEED
	
	if input_dir != Vector3.ZERO:
		anim_player.play("Run")
		var target_angle: float = atan2(input_dir.x, input_dir.z)
		rotation.y = lerp_angle(rotation.y, target_angle, TURN_RATE)
