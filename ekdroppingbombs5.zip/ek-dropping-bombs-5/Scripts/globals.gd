extends Node

var started: bool
var spawning: bool

# TODO #2: Create global score variable.
var score: int

signal hit()
# TODO #3: Create signal to signal when score has been changed.
signal score_changed(score: int)

# TODO #4: Create global function to increase score
func change_score(value: int):
	score += value
	score_changed.emit(score)
