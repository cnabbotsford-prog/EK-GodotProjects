extends Node3D

# Needed to allow the player to select the camera theyre using.
@export var screenSize: Camera3D

# Called every physics frame. 'delta' is the elapsed time since the previous frame.
func _physics_process(_delta):
	# Makes a variable for each side of the viewport, then reduces it by the size of the parent object to make it more accurate
	var leftSide = (-screenSize.get_viewport().size.x/100) + (get_parent().scale.x*2.5)
	var rightSide = (screenSize.get_viewport().size.x/100) - (get_parent().scale.x*2.5)
	var topSide = (screenSize.get_viewport().size.y/100) - (get_parent().scale.y*1.5)
	var bottomSide = (-screenSize.get_viewport().size.y/100) + (get_parent().scale.y*1.5)
	
	# If the parent is on the right or left side of the screen
	if get_parent().position.x > rightSide || get_parent().position.x < leftSide:
		# Clamp it's position to be back inside the screen
		get_parent().position.x = clamp(get_parent().position.x, leftSide, rightSide)
	# If the parent is on the top or bottom side of the screen
	if get_parent().position.y > topSide || get_parent().position.y < bottomSide:
		# Clamp it's position to be back inside the screen
		get_parent().position.y = clamp(get_parent().position.y, bottomSide, topSide)
