extends Node3D

# Creates the speed variable to be set by the player
@export var speed: float

func _ready():
	get_parent().add_to_group("Player")

# A function that happens at the end of the frame when all of the physics are processed
func _physics_process(delta):
	# Sets left and right and up and down based on preset controls being up, down, left, and right buttons
	var horizontal: float
	var vertical: float
	
	if Input.is_key_pressed(KEY_A) || Input.is_key_pressed(KEY_LEFT):
		horizontal = -1
	if Input.is_key_pressed(KEY_D) || Input.is_key_pressed(KEY_RIGHT):
		horizontal = 1
	if Input.is_key_pressed(KEY_S) || Input.is_key_pressed(KEY_DOWN):
		vertical = -1
	if Input.is_key_pressed(KEY_W) || Input.is_key_pressed(KEY_UP):
		vertical = 1
	
	# Creates the final movement variable based on the final variables
	var movement = Vector3(horizontal,vertical,0)
	# Sets the position based on that movement variable times the time passed times the set speed
	get_parent().position += movement * speed * delta
