extends Node3D

# Allows the player to set the camera and parent object's collision
@export var main_camera: Camera3D
@export var bomb_collider: CollisionShape3D
# Private variables for setting the size of the screen and size of the parent object
var screen_bounds: Vector2
var object_width: float
var object_height: float

# Called when the node enters the scene tree for the first time.
func _ready():
	# Randomizes seeds so that the random variables randomize each time
	randomize()
	# Sets the screen bounds object to the size of the screen, dividing by 100 to get to Godot units.
	screen_bounds = Vector2((main_camera.get_viewport().size.x/100), (main_camera.get_viewport().size.y/100))
	# Only really works for objects with Radius, will make one for objects like cubes later
	object_width = bomb_collider.shape.radius
	object_height = bomb_collider.shape.radius
	# Calls the Respawn function
	Respawn()

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta):
	# Checks if the parent object is below the screen
	if get_parent().position.y < (screen_bounds.y * -1 - object_height)-10:
		# if it is, respawns it
		Respawn()

# The respawn function that respawns the parent randomly above the screen
func Respawn():
	# Chooses a random X anywhere from the left to the right side of the screen
	var randomX: float = randf_range(screen_bounds.x + object_width, screen_bounds.x*-1 - object_width)
	# Chooses a random Y anywhere above the screen
	var randomY: float = randf_range((screen_bounds.y + object_height) + 10, (screen_bounds.y + object_height) + 20)
	
	# Sets the parent's position
	get_parent().position = Vector3(randomX, randomY, 0)
	# Gets the 3D Rigidbody of the parent (Will add an option for 2D later) and then sets it's linear velocity to zero to reset the speed
	var rb: RigidBody3D = get_parent()
	rb.linear_velocity = Vector3.ZERO
