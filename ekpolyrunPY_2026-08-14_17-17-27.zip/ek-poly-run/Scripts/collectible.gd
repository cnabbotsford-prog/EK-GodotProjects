extends Area2D

# --------------------
# TODO 8
# _on_body_entered will auto create below when connected
# --------------------
func _on_body_entered(body):
	if body.is_in_group("Player"):
		Globals.change_score(1)
		queue_free()
