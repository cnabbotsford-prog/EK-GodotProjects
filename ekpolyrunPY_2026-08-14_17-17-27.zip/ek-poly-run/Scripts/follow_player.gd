extends Node2D

@export var player : Node2D

func _process(delta):
	global_position.x = player.global_position.x
