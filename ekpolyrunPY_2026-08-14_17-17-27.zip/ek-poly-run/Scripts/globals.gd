extends Node

# --------------------
# TODO 1
# Create the score variable
# --------------------
var score: int = 0;

# --------------------
# TODO 2
# Connect game_end & score_update signal in _ready()
# --------------------
signal game_end()
signal update_score(score: int)

# --------------------
# TODO 5
# Create the restart_game method
# --------------------
func restart_game():
	Engine.time_scale = 1
	get_tree().reload_current_scene()
# --------------------
# TODO 7
# Create the change_score method
# --------------------
func change_score(value: int):
	score += value
	update_score.emit(score)
	
