extends CharacterBody2D

# Define jump height gravity and speed
@export var jump_height: float = 200
var current_gravity: float = 981
var current_speed: float = 260

const BASE_SPEED: float = 250
const BASE_GRAVITY: float = 981

func _physics_process(delta):
	# Set lateral speed
	velocity.x = current_speed
	
	# If in air, apply gravity. If on floor and pressing jump, calculate jump height and set vertical velocity
	if is_on_floor():
		if Input.is_action_just_pressed("jump"):
			velocity.y = sqrt(2 * current_gravity * jump_height) * -1
	else:
		velocity.y += 981 * delta
		
	# Apply velocity to the CharacterBody2D
	move_and_slide()
	
	# --------------------
	# TODO 6
	# Connect game_end & score_update signal
	# --------------------
	if is_on_wall():
		Globals.game_end.emit()


# If score_updated has been implemented in Globals, connect it to check_speed_up
func _ready():
	# --------------------
	# TODO PROVE YOURSELF
	# Explore how check_speed_up and score_updated relate
	# --------------------
	Globals.update_score.connect(check_speed_up)
	pass

# Recalculate player speed from score
func check_speed_up(score: int):
	var speed_modifier: float = (1 + 0.25 * floor(score / 2))
	Engine.time_scale = speed_modifier
