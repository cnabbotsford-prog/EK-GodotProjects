extends Node2D

@export var obstacles : Array[PackedScene]
@export var spawn_delay : float = 7
@onready var timer : Timer = $Timer

func _ready():
	timer.timeout.connect(spawn_obstacle)

func spawn_obstacle():
	var spawned_obstacle : Node2D = obstacles.pick_random().instantiate()
	get_tree().current_scene.add_child(spawned_obstacle)
	spawned_obstacle.global_position = global_position
	restart_timer()
	
func restart_timer():
	timer.wait_time = spawn_delay
	timer.start()
