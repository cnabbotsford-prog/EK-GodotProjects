extends Area2D

# --------------------
# TODO 3
# Create the _on_body_entered method below
# --------------------

func _on_body_entered(body) -> void:
	if body.is_in_group("Player"):
		Globals.game_end.emit()
