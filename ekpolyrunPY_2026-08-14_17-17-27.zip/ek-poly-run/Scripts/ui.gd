extends Control

@onready var score_canvas: Control = $ScoreCanvas
@onready var game_over_canvas: Control = $GameOverCanvas

# --------------------
# TODO 4
# Create the _ready method
# --------------------

func _ready() -> void:
		Globals.game_end.connect(ui_game_over)
		game_over_canvas.get_node("Button").pressed.connect(Globals.restart_game)
		Globals.update_score.connect(ui_update_score)
func ui_game_over() -> void:
	Engine.time_scale = 0
	Globals.score = 0
	game_over_canvas.visible = true

func ui_update_score(score: int) -> void:
	score_canvas.get_node("Label").text = "Score: " + str(score)
